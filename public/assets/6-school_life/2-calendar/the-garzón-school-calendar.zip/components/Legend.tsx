import React from 'react';
import { DayType } from '../types';

interface LegendItemProps {
  colorClass: string;
  label: string;
}

const LegendItem: React.FC<LegendItemProps> = ({ colorClass, label }) => (
  <div className="flex items-center space-x-2">
    <div className={`w-4 h-4 rounded shadow-sm ${colorClass}`}></div>
    <span className="text-xs md:text-sm text-gray-700 font-medium">{label}</span>
  </div>
);

const Legend: React.FC = () => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-stone-200 mt-8">
      <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Guide</h3>
      <div className="flex flex-wrap gap-4 md:gap-6">
        <LegendItem colorClass="bg-emerald-600" label="School Day" />
        <LegendItem colorClass="bg-red-900" label="School Holidays" />
        <LegendItem colorClass="bg-indigo-500" label="Uruguayan National Holiday" />
        <LegendItem colorClass="bg-yellow-500" label="Professional Development Day" />
        <LegendItem colorClass="bg-sky-400" label="Celebration of Learning" />
        {/* Included for completeness based on image legend, even if dates weren't explicit in basic logic */}
        <LegendItem colorClass="bg-emerald-800" label="Summer Learning Camp" />
        <LegendItem colorClass="bg-rose-300" label="Outdoor Learning Camp" />
      </div>
    </div>
  );
};

export default Legend;