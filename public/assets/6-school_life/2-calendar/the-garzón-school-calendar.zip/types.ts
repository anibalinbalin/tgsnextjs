export enum DayType {
  SCHOOL_DAY = 'SCHOOL_DAY',
  SCHOOL_HOLIDAY = 'SCHOOL_HOLIDAY',
  NATIONAL_HOLIDAY = 'NATIONAL_HOLIDAY',
  PD_DAY = 'PD_DAY', // Professional Development
  SUMMER_CAMP = 'SUMMER_CAMP',
  OUTDOOR_CAMP = 'OUTDOOR_CAMP',
  CELEBRATION = 'CELEBRATION',
  WEEKEND = 'WEEKEND',
  EMPTY = 'EMPTY' // Padding for start of month
}

export interface CalendarDay {
  date: Date;
  type: DayType;
  dayOfMonth: number;
  label?: string; // For specific holiday names
}

export interface MonthData {
  name: string;
  year: number;
  monthIndex: number; // 0-11
  days: CalendarDay[];
}

export interface Term {
  name: string;
  dates: string;
}

export const TERMS: Term[] = [
  { name: 'TERM 1', dates: 'March 5th - April 30th' },
  { name: 'TERM 2', dates: 'May 12th - July 4th' },
  { name: 'TERM 3', dates: 'August 4th - October 10th' },
  { name: 'TERM 4', dates: 'October 20th - December 12th' },
];