import { DayType, CalendarDay, MonthData } from './types';

// Helper to check if a date falls within a range (inclusive)
const isBetween = (date: Date, start: Date, end: Date) => {
  return date.getTime() >= start.getTime() && date.getTime() <= end.getTime();
};

const isSameDay = (d1: Date, d2: Date) => {
  return d1.getFullYear() === d2.getFullYear() &&
         d1.getMonth() === d2.getMonth() &&
         d1.getDate() === d2.getDate();
};

// Core logic to determine the type of day based on the 2025 Image
export const getDayType = (date: Date): DayType => {
  const year = date.getFullYear();
  const month = date.getMonth(); // 0-11
  const day = date.getDate();
  const dayOfWeek = date.getDay(); // 0 = Sun, 6 = Sat

  if (year !== 2025) return DayType.EMPTY;

  // Weekends are generally weekends, but some logic might override this (e.g. camps)
  // However, looking at the image, weekends are always blank/white unless specified.
  if (dayOfWeek === 0 || dayOfWeek === 6) return DayType.WEEKEND;

  // Specific Dates from Image Analysis
  
  // -- NATIONAL HOLIDAYS (Blueish/Gray) --
  // Estimated from image
  const nationalHolidays = [
    new Date(2025, 2, 3), // Mar 3 (Carnival)
    new Date(2025, 2, 4), // Mar 4 (Carnival)
    new Date(2025, 3, 17), // Apr 17 (Tourism Week)
    new Date(2025, 3, 18), // Apr 18 (Tourism Week)
    new Date(2025, 4, 1),  // May 1 (Labor Day)
    new Date(2025, 5, 19), // Jun 19 (Artigas)
    new Date(2025, 6, 18), // Jul 18 (Constitution)
    new Date(2025, 7, 25), // Aug 25 (Independence)
    new Date(2025, 11, 25), // Dec 25 (Xmas) - Though mostly covered by holidays
  ];
  if (nationalHolidays.some(h => isSameDay(h, date))) return DayType.NATIONAL_HOLIDAY;

  // -- PROFESSIONAL DEVELOPMENT (Gold) --
  const pdDays = [
    new Date(2025, 4, 2),  // May 2 (Bridge day?)
    new Date(2025, 7, 1),  // Aug 1 (Friday before term 3)
  ];
  if (pdDays.some(d => isSameDay(d, date))) return DayType.PD_DAY;

  // -- CELEBRATION OF LEARNING (Light Blue) --
  const celebrationDays = [
    new Date(2025, 3, 30), // Apr 30
    new Date(2025, 6, 4),  // July 4
    new Date(2025, 9, 10), // Oct 10
    new Date(2025, 11, 12), // Dec 12
  ];
  if (celebrationDays.some(d => isSameDay(d, date))) return DayType.CELEBRATION;

  // -- CAMPS --
  // Summer Camp (Dark Green): Feb 3 - Feb 14 (Guessing based on typical schedules or patterns, 
  // actually looking at image, Feb is mostly red. Let's look at the legend.
  // Wait, Looking closely at Feb in image: Feb 10-21 looks like Dark Green?)
  // Let's refine based on the visual blocks.
  
  // Actually, looking at image:
  // Jan is all Red.
  // Feb 3-28 is Red. 
  // Let's stick strictly to the visual blocks we see.
  
  // -- SCHOOL HOLIDAYS (Red/Maroon) --
  if (month === 0) return DayType.SCHOOL_HOLIDAY; // All Jan
  if (month === 1) return DayType.SCHOOL_HOLIDAY; // All Feb (Assume for now unless overriden)
  
  // March Holidays: 1-2 (Weekend), 3-4 (Nat Holiday)
  // Term 1 Starts March 5.
  
  // April Holidays: 14-18 (Tourism week)
  if (month === 3 && day >= 14 && day <= 18) {
      if (day === 17 || day === 18) return DayType.NATIONAL_HOLIDAY;
      return DayType.SCHOOL_HOLIDAY;
  }
  
  // May Holidays: 1 (Nat), 2 (PD).
  
  // Winter Break: July 7 - Aug 1
  if (isBetween(date, new Date(2025, 6, 7), new Date(2025, 7, 1))) {
      // Check for PD day override on Aug 1
      if (month === 7 && day === 1) return DayType.PD_DAY; 
      if (month === 6 && day === 18) return DayType.NATIONAL_HOLIDAY;
      return DayType.SCHOOL_HOLIDAY;
  }

  // Spring Break: Sept 22 - Sept 26
  if (isBetween(date, new Date(2025, 8, 22), new Date(2025, 8, 26))) return DayType.SCHOOL_HOLIDAY;

  // End of Year: Dec 13 onwards
  if (month === 11 && day >= 13) return DayType.SCHOOL_HOLIDAY;


  // -- SCHOOL DAYS (Green) --
  // Term 1: Mar 5 - Apr 30
  if (isBetween(date, new Date(2025, 2, 5), new Date(2025, 3, 30))) return DayType.SCHOOL_DAY;
  
  // Term 2: May 12 - July 4
  if (isBetween(date, new Date(2025, 4, 12), new Date(2025, 6, 4))) return DayType.SCHOOL_DAY;

  // Term 3: Aug 4 - Oct 10
  if (isBetween(date, new Date(2025, 7, 4), new Date(2025, 9, 10))) return DayType.SCHOOL_DAY;

  // Term 4: Oct 20 - Dec 12
  if (isBetween(date, new Date(2025, 9, 20), new Date(2025, 11, 12))) return DayType.SCHOOL_DAY;

  return DayType.EMPTY; // Default fallback
};


export const generateYearData = (year: number): MonthData[] => {
  const months: MonthData[] = [];
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  for (let i = 0; i < 12; i++) {
    const firstDay = new Date(year, i, 1);
    const lastDay = new Date(year, i + 1, 0);
    const numDays = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay(); // 0 (Sun) - 6 (Sat)

    const days: CalendarDay[] = [];

    // Add padding for start of month
    // We want Monday to be the first column in the grid usually for international schools, 
    // but the image shows Sunday first (S M T W T F S).
    for (let j = 0; j < startDayOfWeek; j++) {
      days.push({
        date: new Date(year, i, 1), // Dummy date
        type: DayType.EMPTY,
        dayOfMonth: 0
      });
    }

    // Add actual days
    for (let d = 1; d <= numDays; d++) {
      const currentDate = new Date(year, i, d);
      days.push({
        date: currentDate,
        type: getDayType(currentDate),
        dayOfMonth: d
      });
    }

    months.push({
      name: monthNames[i],
      year,
      monthIndex: i,
      days
    });
  }

  return months;
};