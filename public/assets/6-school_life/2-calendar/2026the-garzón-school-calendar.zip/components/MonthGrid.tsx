import React from 'react';
import { MonthData, DayType } from '../types';

interface MonthGridProps {
  data: MonthData;
  onClick?: () => void;
  isLarge?: boolean;
}

const getDayStyle = (type: DayType): string => {
  switch (type) {
    case DayType.SCHOOL_DAY: return 'bg-emerald-600 text-white hover:bg-emerald-500';
    case DayType.SCHOOL_HOLIDAY: return 'bg-red-900 text-white hover:bg-red-800';
    case DayType.NATIONAL_HOLIDAY: return 'bg-indigo-800 text-white hover:bg-indigo-700';
    case DayType.PD_DAY: return 'bg-amber-400 text-white hover:bg-amber-300';
    case DayType.CELEBRATION: return 'bg-blue-400 text-white hover:bg-blue-300';
    case DayType.ORIENTATION_CAMP: return 'bg-rose-400 text-white hover:bg-rose-300';
    case DayType.SUMMER_CAMP: return 'bg-lime-700 text-white';
    case DayType.OUTDOOR_CAMP: return 'bg-rose-300 text-white';
    case DayType.WEEKEND: return 'bg-white text-gray-400';
    case DayType.EMPTY: return 'bg-transparent';
    default: return 'bg-white text-gray-800';
  }
};

const MonthGrid: React.FC<MonthGridProps> = ({ data, onClick, isLarge = false }) => {
  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div 
      onClick={onClick}
      className={`
        bg-white border-2 border-stone-800 shadow-[4px_4px_0px_0px_rgba(40,40,40,0.2)] 
        transition-all duration-300 
        ${!isLarge ? 'hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(40,40,40,0.3)] cursor-pointer' : ''}
        flex flex-col
      `}
    >
      {/* Header */}
      <div className="bg-[#bda67d] p-2 text-center border-b-2 border-stone-800">
        <h3 className={`font-bold uppercase tracking-widest text-stone-900 ${isLarge ? 'text-2xl' : 'text-sm'}`}>
          {data.name}
        </h3>
      </div>

      {/* Grid */}
      <div className="p-2 md:p-4 flex-1">
        {/* Days Header */}
        <div className="grid grid-cols-7 mb-2">
          {daysOfWeek.map((day, i) => (
            <div key={i} className="text-center text-[10px] md:text-xs font-bold text-stone-500">
              {day}
            </div>
          ))}
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1">
          {data.days.map((day, idx) => {
            if (day.type === DayType.EMPTY) {
              return <div key={idx} className="aspect-square"></div>;
            }

            const styles = getDayStyle(day.type);
            
            return (
              <div 
                key={idx} 
                className={`
                  aspect-square flex items-center justify-center 
                  text-[10px] ${isLarge ? 'md:text-lg' : 'md:text-xs'} font-bold rounded-sm
                  transition-colors duration-200
                  ${styles}
                `}
                title={day.type.replace('_', ' ')}
              >
                {day.dayOfMonth}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default MonthGrid;