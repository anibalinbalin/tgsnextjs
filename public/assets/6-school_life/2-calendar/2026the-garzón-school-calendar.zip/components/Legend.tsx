import React from 'react';
import { DayType } from '../types';

interface LegendItemProps {
  colorClass: string;
  label: string;
}

const LegendItem: React.FC<LegendItemProps> = ({ colorClass, label }) => (
  <div className="flex items-center space-x-2">
    <div className={`w-4 h-4 rounded shadow-sm ${colorClass}`}></div>
    <span className="text-xs md:text-sm text-gray-700 font-medium">{label}</span>
  </div>
);

const Legend: React.FC = () => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-stone-200 mt-8">
      <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Guide</h3>
      <div className="flex flex-wrap gap-4 md:gap-6">
        <LegendItem colorClass="bg-emerald-600" label="School Day" />
        <LegendItem colorClass="bg-red-900" label="School Holidays" />
        <LegendItem colorClass="bg-indigo-800" label="Uruguayan National Holiday" />
        <LegendItem colorClass="bg-amber-400" label="Professional Development Day" />
        <LegendItem colorClass="bg-blue-400" label="Celebration of Learning" />
        <LegendItem colorClass="bg-rose-400" label="Orientation Learning Camp (new students)" />
        {/* Included based on bottom legend of image */}
        <LegendItem colorClass="bg-lime-700" label="Summer Learning Camp" />
      </div>
    </div>
  );
};

export default Legend;