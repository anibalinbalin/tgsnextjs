import { DayType, CalendarDay, MonthData } from './types';

// Helper to check if a date falls within a range (inclusive)
const isBetween = (date: Date, start: Date, end: Date) => {
  const d = date.getTime();
  return d >= start.getTime() && d <= end.getTime();
};

const isSameDay = (d1: Date, d2: Date) => {
  return d1.getFullYear() === d2.getFullYear() &&
         d1.getMonth() === d2.getMonth() &&
         d1.getDate() === d2.getDate();
};

// Core logic to determine the type of day based on the 2026 Image
export const getDayType = (date: Date): DayType => {
  const year = date.getFullYear();
  const month = date.getMonth(); // 0-11
  const day = date.getDate();
  const dayOfWeek = date.getDay(); // 0 = Sun, 6 = Sat

  if (year !== 2026) return DayType.EMPTY;

  // Weekends
  if (dayOfWeek === 0 || dayOfWeek === 6) return DayType.WEEKEND;

  // -- SPECIFIC EVENTS FIRST (Override general ranges) --

  // Orientation Learning Camp (New Students): Feb 18, 19, 20
  const orientationDays = [
    new Date(2026, 1, 18),
    new Date(2026, 1, 19),
    new Date(2026, 1, 20),
  ];
  if (orientationDays.some(d => isSameDay(d, date))) return DayType.ORIENTATION_CAMP;

  // Celebration of Learning (Blue): Apr 23, Jul 2, Oct 8, Dec 11
  const celebrationDays = [
    new Date(2026, 3, 23), // Apr 23
    new Date(2026, 6, 2),  // Jul 2
    new Date(2026, 9, 8),  // Oct 8
    new Date(2026, 11, 11), // Dec 11
  ];
  if (celebrationDays.some(d => isSameDay(d, date))) return DayType.CELEBRATION;

  // Professional Development Days (Gold): Apr 24, Jul 3, Oct 9
  const pdDays = [
    new Date(2026, 3, 24), // Apr 24
    new Date(2026, 6, 3),  // Jul 3
    new Date(2026, 9, 9),  // Oct 9
  ];
  if (pdDays.some(d => isSameDay(d, date))) return DayType.PD_DAY;

  // National Holidays (Purple/Dark)
  const nationalHolidays = [
    new Date(2026, 4, 1),   // May 1 (Labor Day)
    new Date(2026, 4, 18),  // May 18 (Battle of Las Piedras)
    new Date(2026, 5, 19),  // Jun 19 (Artigas)
    new Date(2026, 6, 18),  // Jul 18 (Constitution)
    new Date(2026, 7, 25),  // Aug 25 (Independence)
    new Date(2026, 10, 2),  // Nov 2 (All Souls)
    new Date(2026, 11, 25), // Dec 25 (Christmas)
  ];
  if (nationalHolidays.some(h => isSameDay(h, date))) return DayType.NATIONAL_HOLIDAY;


  // -- RANGES --

  // School Holidays (Maroon)
  // Summer Break Part 1
  if (month === 0) return DayType.SCHOOL_HOLIDAY; // All Jan
  if (month === 1 && day <= 17) return DayType.SCHOOL_HOLIDAY; // Feb 1-17

  // Autumn Break: Apr 27 - Apr 30 (Apr 24 is PD, May 1 is Holiday)
  if (month === 3 && day >= 27) return DayType.SCHOOL_HOLIDAY;

  // Winter Break: July 6 - July 31 (July 2 is Celeb, July 3 is PD)
  if (isBetween(date, new Date(2026, 6, 6), new Date(2026, 6, 31))) return DayType.SCHOOL_HOLIDAY;

  // Spring Break: Oct 12 - Oct 16 (Oct 8 Celeb, Oct 9 PD)
  if (isBetween(date, new Date(2026, 9, 12), new Date(2026, 9, 16))) return DayType.SCHOOL_HOLIDAY;

  // Summer Break Part 2: Dec 14 onwards
  if (month === 11 && day >= 14) return DayType.SCHOOL_HOLIDAY;


  // School Days (Green)
  // Term 1: Feb 18 - Apr 23 (Feb 18-20 are Orientation, regular classes start Feb 23)
  // Note: We already handled Orientation/Celeb/PD specific days above.
  // So anything left in the term ranges is a School Day.
  
  // Term 1 Range
  if (isBetween(date, new Date(2026, 1, 18), new Date(2026, 3, 23))) return DayType.SCHOOL_DAY;
  
  // Term 2 Range: May 4 - Jul 2
  if (isBetween(date, new Date(2026, 4, 4), new Date(2026, 6, 2))) return DayType.SCHOOL_DAY;

  // Term 3 Range: Aug 3 - Oct 8
  if (isBetween(date, new Date(2026, 7, 3), new Date(2026, 9, 8))) return DayType.SCHOOL_DAY;

  // Term 4 Range: Oct 19 - Dec 11
  if (isBetween(date, new Date(2026, 9, 19), new Date(2026, 11, 11))) return DayType.SCHOOL_DAY;

  return DayType.EMPTY; // Default fallback (should mostly be weekends or padding)
};


export const generateYearData = (year: number): MonthData[] => {
  const months: MonthData[] = [];
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  for (let i = 0; i < 12; i++) {
    const firstDay = new Date(year, i, 1);
    const lastDay = new Date(year, i + 1, 0);
    const numDays = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay(); // 0 (Sun) - 6 (Sat)

    const days: CalendarDay[] = [];

    // Add padding for start of month
    for (let j = 0; j < startDayOfWeek; j++) {
      days.push({
        date: new Date(year, i, 1), // Dummy date
        type: DayType.EMPTY,
        dayOfMonth: 0
      });
    }

    // Add actual days
    for (let d = 1; d <= numDays; d++) {
      const currentDate = new Date(year, i, d);
      days.push({
        date: currentDate,
        type: getDayType(currentDate),
        dayOfMonth: d
      });
    }

    months.push({
      name: monthNames[i],
      year,
      monthIndex: i,
      days
    });
  }

  return months;
};