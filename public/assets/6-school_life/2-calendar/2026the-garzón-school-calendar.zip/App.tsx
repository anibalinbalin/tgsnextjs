import React, { useState, useMemo } from 'react';
import { generateYearData } from './utils';
import { MonthData, TERMS } from './types';
import MonthGrid from './components/MonthGrid';
import MonthModal from './components/MonthModal';
import Legend from './components/Legend';
import { Bird } from 'lucide-react';

const App: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState<MonthData | null>(null);
  
  // Initialize calendar data for 2026
  const calendarData = useMemo(() => generateYearData(2026), []);

  return (
    <div className="min-h-screen p-4 md:p-8 lg:p-12 text-stone-800">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Section */}
        <header className="flex flex-col md:flex-row justify-between items-center mb-12 border-b-2 border-stone-800 pb-8">
          
          {/* Terms Info (Left) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 text-sm mb-8 md:mb-0 w-full md:w-auto">
            {TERMS.slice(0, 2).map((term, i) => (
              <div key={i}>
                <h3 className="font-bold uppercase tracking-wider text-stone-900">{term.name}</h3>
                <p className="text-stone-600">{term.dates}</p>
              </div>
            ))}
          </div>

          {/* Logo / Title (Center) */}
          <div className="flex flex-col items-center text-center mx-8">
             <div className="mb-2">
                {/* Using a bird icon to approximate the logo */}
                <Bird className="w-16 h-16 text-stone-800" strokeWidth={1} />
             </div>
             <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-2">THE GARZÓN SCHOOL</h1>
             <div className="text-xl tracking-[0.2em] font-light">2026 PROVISIONAL CALENDAR</div>
          </div>

          {/* Terms Info (Right) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 text-sm w-full md:w-auto text-right md:text-left">
            {TERMS.slice(2, 4).map((term, i) => (
              <div key={i}>
                <h3 className="font-bold uppercase tracking-wider text-stone-900">{term.name}</h3>
                <p className="text-stone-600">{term.dates}</p>
              </div>
            ))}
          </div>
        </header>

        {/* Calendar Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {calendarData.map((month) => (
            <MonthGrid 
              key={month.monthIndex} 
              data={month} 
              onClick={() => setSelectedMonth(month)}
            />
          ))}
        </div>

        {/* Legend */}
        <Legend />

        {/* Footer info */}
        <div className="mt-12 text-center text-stone-500 text-sm">
          <p>Click on any month to view details and specific events.</p>
        </div>

      </div>

      {/* Modal */}
      {selectedMonth && (
        <MonthModal 
          data={selectedMonth} 
          onClose={() => setSelectedMonth(null)} 
        />
      )}
    </div>
  );
};

export default App;