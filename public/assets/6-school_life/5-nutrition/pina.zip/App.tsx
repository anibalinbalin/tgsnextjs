import React, { useState } from 'react';
import { WEEK_A, WEEK_B } from './constants';
import { WeekType } from './types';
import Header from './components/Header';
import MenuGrid from './components/MenuGrid';
import MenuMobile from './components/MenuMobile';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [currentWeek, setCurrentWeek] = useState<WeekType>('A');

  const activeData = currentWeek === 'A' ? WEEK_A : WEEK_B;

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900 bg-[#FDFBF7]">
      <Header 
        currentWeek={currentWeek} 
        dates={activeData.dates} 
        onToggleWeek={setCurrentWeek} 
      />

      <main className="flex-grow container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-[#5D4037] mb-2 flex items-center gap-3">
             <span className="w-2 h-8 bg-[#D87D4A] rounded-full inline-block"></span>
             Menú Semanal
          </h2>
          <p className="text-gray-600">
            Explora nuestras opciones saludables para la 
            <span className="font-bold text-[#D87D4A]"> Semana {currentWeek}</span>.
          </p>
        </div>

        {/* Responsive Views */}
        <div className="hidden lg:block">
           <MenuGrid days={activeData.days} />
        </div>
        <div className="lg:hidden">
           <MenuMobile days={activeData.days} />
        </div>

      </main>

      <Footer />
    </div>
  );
};

export default App;