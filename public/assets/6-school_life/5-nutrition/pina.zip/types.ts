export type WeekType = 'A' | 'B';

export interface DayMenu {
  day: string;
  snackMatutino: string;
  mainProtein: string;
  mainVeggie: string;
  sideDish: string; // Guarnición
  salads: string[]; // Ensaladas
  dessert: string; // Postre
  afternoonSnack: string; // Snack de la tarde
}

export interface WeekData {
  id: WeekType;
  dates: string[];
  days: DayMenu[];
}