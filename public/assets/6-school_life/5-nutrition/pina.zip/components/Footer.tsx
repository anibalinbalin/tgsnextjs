import React from 'react';
import { Info, Wheat, Leaf, MilkOff } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#5D4037] text-white/80 py-8 px-4 mt-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
        
        <div className="space-y-4">
          <h4 className="font-bold text-white flex items-center gap-2">
            <Info size={18} className="text-[#D87D4A]" />
            Sobre Nuestro Menú
          </h4>
          <p>
            En nuestra cantina nos preocupamos por la salud y el bienestar de los más pequeños. 
            Ofrecemos un menú especial que evita harinas blancas refinadas, priorizando opciones 
            más saludables como harina de avena y almendras de coco.
          </p>
          <p>
            Endulzamos con alternativas naturales: azúcar de coco, dátiles, miel y stevia. 
            ¡Sabores irresistibles sin aditivos artificiales!
          </p>
        </div>

        <div className="space-y-4">
           <h4 className="font-bold text-white">Referencias</h4>
           <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-lg">
                <Wheat size={16} className="text-[#D87D4A]" />
                <span>Gluten Free</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-lg">
                <Leaf size={16} className="text-green-400" />
                <span>Vegetariano</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-lg">
                <Leaf size={16} className="text-green-200" />
                <span>Vegano</span>
              </div>
           </div>
           <p className="text-xs italic mt-4">
             Las ensaladas siempre cuentan con aliños variados: oliva, pimienta, pesto verde, gremolata, etc.
             Ofrecemos infusiones y aguas saborizadas naturales.
           </p>
        </div>
      </div>
      
      <div className="max-w-6xl mx-auto mt-8 pt-8 border-t border-white/10 text-center text-xs text-white/40">
        &copy; {new Date().getFullYear()} Piñadulce Comedor Escolar.
      </div>
    </footer>
  );
};

export default Footer;