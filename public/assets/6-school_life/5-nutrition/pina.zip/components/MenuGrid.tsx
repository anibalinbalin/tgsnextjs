import React from 'react';
import { DayMenu } from '../types';
import { Utensils, Coffee, Leaf, Carrot, Cookie, Sun, Moon } from 'lucide-react';

interface MenuGridProps {
  days: DayMenu[];
}

const MenuGrid: React.FC<MenuGridProps> = ({ days }) => {
  const categories = [
    { label: 'Snack Matutino', key: 'snackMatutino', icon: <Sun size={18} className="text-[#D87D4A]" /> },
    { label: 'Principales Proteína', key: 'mainProtein', icon: <Utensils size={18} className="text-[#5D4037]" /> },
    { label: 'Principales Veggie', key: 'mainVeggie', icon: <Leaf size={18} className="text-green-600" /> },
    { label: 'Guarnición', key: 'sideDish', icon: <Carrot size={18} className="text-orange-500" /> },
    { label: 'Ensaladas', key: 'salads', icon: <Leaf size={18} className="text-green-500" /> },
    { label: 'Postre', key: 'dessert', icon: <Cookie size={18} className="text-purple-500" /> },
    { label: 'Snack Tarde', key: 'afternoonSnack', icon: <Moon size={18} className="text-indigo-500" /> },
  ];

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1000px]">
          <thead>
            <tr className="bg-[#5D4037] text-white">
              <th className="p-4 w-48 text-left font-bold border-r border-[#6D4C42]">Categoría</th>
              {days.map((d) => (
                <th key={d.day} className="p-4 w-1/5 text-center font-bold border-l border-[#6D4C42] first:border-l-0">
                  {d.day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {categories.map((cat, idx) => (
              <tr key={cat.key} className={idx % 2 === 0 ? 'bg-[#FDFBF7]' : 'bg-white'}>
                {/* Category Header Column */}
                <td className="p-4 border-r border-gray-200">
                  <div className="flex items-center gap-3 font-semibold text-[#5D4037] uppercase text-sm tracking-wider">
                    <div className="bg-white p-2 rounded-full shadow-sm border border-gray-100">
                      {cat.icon}
                    </div>
                    {cat.label}
                  </div>
                </td>
                
                {/* Day Columns */}
                {days.map((d) => (
                  <td key={`${d.day}-${cat.key}`} className="p-4 border-l border-gray-200 align-top">
                    <div className="text-sm text-gray-700 leading-relaxed font-medium">
                      {cat.key === 'salads' ? (
                        <ul className="list-disc list-inside space-y-1">
                          {(d[cat.key as keyof DayMenu] as string[]).map((salad, i) => (
                            <li key={i} className="marker:text-[#D87D4A]">{salad}</li>
                          ))}
                        </ul>
                      ) : (
                        <span>{d[cat.key as keyof DayMenu]}</span>
                      )}
                    </div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MenuGrid;