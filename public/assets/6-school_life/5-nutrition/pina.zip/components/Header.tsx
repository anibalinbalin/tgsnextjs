import React from 'react';
import { WeekType } from '../types';
import { Calendar, ChevronRight } from 'lucide-react';

interface HeaderProps {
  currentWeek: WeekType;
  dates: string[];
  onToggleWeek: (week: WeekType) => void;
}

const Header: React.FC<HeaderProps> = ({ currentWeek, dates, onToggleWeek }) => {
  return (
    <header className="bg-[#5D4037] text-white py-6 px-4 shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          
          {/* Logo / Brand */}
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 border-2 border-white rounded-full flex items-center justify-center">
               <span className="text-xl font-bold">P</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-wide uppercase">Piñadulce</h1>
              <p className="text-xs text-[#D87D4A] tracking-wider uppercase">Menú Term 4</p>
            </div>
          </div>

          {/* Week Selector */}
          <div className="flex items-center bg-[#4A322C] rounded-full p-1 border border-[#6D4C42]">
            <button
              onClick={() => onToggleWeek('A')}
              className={`px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                currentWeek === 'A'
                  ? 'bg-[#D87D4A] text-white shadow-md'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              SEMANA A
            </button>
            <button
              onClick={() => onToggleWeek('B')}
              className={`px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                currentWeek === 'B'
                  ? 'bg-[#D87D4A] text-white shadow-md'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              SEMANA B
            </button>
          </div>

        </div>

        {/* Date Ranges */}
        <div className="mt-4 pt-4 border-t border-[#6D4C42] text-xs md:text-sm text-gray-300 flex flex-wrap justify-center gap-x-6 gap-y-2">
          {dates.map((date, idx) => (
            <div key={idx} className="flex items-center gap-1">
              <Calendar size={12} className="text-[#D87D4A]" />
              <span>{date}</span>
            </div>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;