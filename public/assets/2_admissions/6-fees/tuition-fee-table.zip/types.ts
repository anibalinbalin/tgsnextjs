export interface NestGroup {
  name: string;
  grades: string[];
}

export interface TuitionTier {
  price: number;
  nests: NestGroup[];
}