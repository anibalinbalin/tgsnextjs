import React from 'react';
import TuitionTable from './components/TuitionTable';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-8 bg-gray-50">
      <div className="text-center mb-8 max-w-2xl">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">School Admin Portal</h1>
        <p className="text-gray-600">
          The table below is generated dynamically. To edit prices, grades, or groups, 
          simply update the configuration file in the project code.
        </p>
      </div>

      <TuitionTable />
      
    </div>
  );
};

export default App;