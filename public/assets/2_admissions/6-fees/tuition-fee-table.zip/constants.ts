import { TuitionTier } from './types';

/**
 * WEBMASTER INSTRUCTIONS:
 * 
 * To update the table:
 * 1. Find the 'tuitionData' array below.
 * 2. It is organized by Price Tiers. 
 * 3. Inside each price tier, you have 'nests' (e.g., Penguins).
 * 4. Inside each nest, you have 'grades' (e.g., K2, K3).
 * 
 * The table will automatically calculate the row heights (rowspans) based on this data.
 */

export const TABLE_HEADERS = {
  title: "TUITION FEE (ANUALIDAD)",
  columns: ["GRADE", "NEST", "ANNUAL TUITION (USD)"]
};

// Color configuration to match the image
export const THEME_COLORS = {
  headerBg: "bg-[#C6B696]", // The specific beige/tan from the image
  border: "border-black",
  text: "text-black"
};

export const tuitionData: TuitionTier[] = [
  {
    price: 10800,
    nests: [
      {
        name: "PENGUINS",
        grades: ["K2", "K3"]
      }
    ]
  },
  {
    price: 21600,
    nests: [
      {
        name: "JAYS",
        grades: ["K4", "K5"]
      },
      {
        name: "OWLS",
        grades: ["P1", "P2"]
      },
      {
        name: "ROBINS",
        grades: ["P3", "P4"]
      },
      {
        name: "FALCONS",
        grades: ["P5", "P6"]
      }
    ]
  },
  {
    price: 23600,
    nests: [
      {
        name: "BOSQUE",
        grades: ["S1", "S2"]
      },
      {
        name: "RÍO",
        grades: ["S3"] // Assuming S3 is alone or part of this block based on image logic, though image cuts off slightly, extrapolated S3 is in the S tier.
      }
    ]
  }
];