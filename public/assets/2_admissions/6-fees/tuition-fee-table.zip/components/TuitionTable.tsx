import React from 'react';
import { tuitionData, TABLE_HEADERS, THEME_COLORS } from '../constants';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(amount);
};

const TuitionTable: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      {/* Wrapper for responsive scrolling on mobile */}
      <div className="overflow-x-auto shadow-lg">
        <table className={`w-full min-w-[600px] border-collapse text-center font-mono ${THEME_COLORS.text}`}>
          <thead>
            {/* Main Title Row */}
            <tr className={`${THEME_COLORS.headerBg}`}>
              <th 
                colSpan={3} 
                className={`border-2 ${THEME_COLORS.border} py-3 px-4 text-xl font-bold uppercase tracking-wide`}
              >
                {TABLE_HEADERS.title}
              </th>
            </tr>
            {/* Column Headers */}
            <tr className={`${THEME_COLORS.headerBg}`}>
              {TABLE_HEADERS.columns.map((col, index) => (
                <th
                  key={col}
                  className={`border-2 ${THEME_COLORS.border} py-2 px-4 font-bold uppercase w-1/3`}
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white">
            {tuitionData.map((tier, tierIndex) => {
              // Calculate total rows needed for this price tier to set rowspan
              const totalTierRows = tier.nests.reduce(
                (sum, nest) => sum + nest.grades.length,
                0
              );

              return (
                <React.Fragment key={`tier-${tierIndex}`}>
                  {tier.nests.map((nest, nestIndex) => (
                    <React.Fragment key={`nest-${nest.name}`}>
                      {nest.grades.map((grade, gradeIndex) => {
                        // Logic to determine when to render merged cells
                        const isFirstRowOfTier = nestIndex === 0 && gradeIndex === 0;
                        const isFirstRowOfNest = gradeIndex === 0;

                        return (
                          <tr key={grade}>
                            {/* GRADE COLUMN: Always rendered for every row */}
                            <td className={`border-2 ${THEME_COLORS.border} p-3 font-semibold text-lg`}>
                              {grade}
                            </td>

                            {/* NEST COLUMN: Rendered only on the first grade of the nest */}
                            {isFirstRowOfNest && (
                              <td
                                className={`border-2 ${THEME_COLORS.border} p-3 font-bold uppercase tracking-wider`}
                                rowSpan={nest.grades.length}
                              >
                                {nest.name}
                              </td>
                            )}

                            {/* PRICE COLUMN: Rendered only on the very first row of the entire tier */}
                            {isFirstRowOfTier && (
                              <td
                                className={`border-2 ${THEME_COLORS.border} p-3 text-xl font-bold`}
                                rowSpan={totalTierRows}
                              >
                                {formatCurrency(tier.price)}
                              </td>
                            )}
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-sm text-gray-500 font-mono text-center">
        * Tuition fees are subject to annual review.
      </p>
    </div>
  );
};

export default TuitionTable;