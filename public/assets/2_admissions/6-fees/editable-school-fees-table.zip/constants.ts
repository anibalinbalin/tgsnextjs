import { FeeData } from './types';

export const INITIAL_FEE_DATA: FeeData = {
  applicationFee: {
    title: "APPLICATION FEE (USD) **",
    amount: "$300"
  },
  enrolmentFee: {
    title: "ENROLMENT FEE (USD) (INSCRIPCIÓN) **",
    amount: "$9500"
  },
  siblingDiscounts: {
    title: "SIBLING DISCOUNTS",
    columns: {
      tuition: "TUITION FEE",
      enrolment: "ENROLMENT FEE"
    },
    rows: [
      { id: '1', label: '2nd child', tuitionDiscount: '10%', enrolmentDiscount: '40%' },
      { id: '2', label: '3rd child', tuitionDiscount: '15%', enrolmentDiscount: '50%' },
      { id: '3', label: '4th child', tuitionDiscount: '20%', enrolmentDiscount: '60%' },
    ]
  },
  footnote: "** Applies only to new families starting in 2026"
};