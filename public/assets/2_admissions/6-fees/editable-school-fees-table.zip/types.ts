export interface FeeSection {
  title: string;
  amount: string;
}

export interface DiscountRow {
  id: string;
  label: string;
  tuitionDiscount: string;
  enrolmentDiscount: string;
}

export interface FeeData {
  applicationFee: FeeSection;
  enrolmentFee: FeeSection;
  siblingDiscounts: {
    title: string;
    columns: {
      tuition: string;
      enrolment: string;
    };
    rows: DiscountRow[];
  };
  footnote: string;
}