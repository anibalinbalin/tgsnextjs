import React, { useState, useEffect, useRef } from 'react';

interface EditableFieldProps {
  value: string;
  isEditing: boolean;
  onChange: (newValue: string) => void;
  className?: string;
  multiline?: boolean;
}

export const EditableField: React.FC<EditableFieldProps> = ({ 
  value, 
  isEditing, 
  onChange, 
  className = "",
  multiline = false
}) => {
  const [localValue, setLocalValue] = useState(value);

  // Sync local state if prop changes (e.g. from a reset)
  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setLocalValue(e.target.value);
    onChange(e.target.value);
  };

  if (isEditing) {
    if (multiline) {
      return (
        <textarea
          value={localValue}
          onChange={handleChange}
          className={`w-full bg-white/50 border border-blue-400 rounded px-1 text-inherit focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`}
          rows={2}
        />
      );
    }
    return (
      <input
        type="text"
        value={localValue}
        onChange={handleChange}
        className={`w-full bg-white/50 border border-blue-400 rounded px-1 text-inherit text-center focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`}
      />
    );
  }

  return <span className={className}>{value}</span>;
};