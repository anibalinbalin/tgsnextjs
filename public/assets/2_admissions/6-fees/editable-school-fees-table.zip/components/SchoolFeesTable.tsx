import React from 'react';
import { FeeData } from '../types';
import { EditableField } from './EditableField';

interface SchoolFeesTableProps {
  data: FeeData;
  setData: (data: FeeData) => void;
  isEditable: boolean;
}

// The specific beige color from the image
const THEME_COLOR = 'bg-[#D2Cbb8]'; // Adjusted to match the khaki/beige tone
const BORDER_COLOR = 'border-black';

export const SchoolFeesTable: React.FC<SchoolFeesTableProps> = ({ data, setData, isEditable }) => {
  
  // Handlers for updating specific parts of the complex data object
  const updateAppFee = (field: 'title' | 'amount', val: string) => {
    setData({
      ...data,
      applicationFee: { ...data.applicationFee, [field]: val }
    });
  };

  const updateEnrolmentFee = (field: 'title' | 'amount', val: string) => {
    setData({
      ...data,
      enrolmentFee: { ...data.enrolmentFee, [field]: val }
    });
  };

  const updateSiblingDiscountHeader = (val: string) => {
    setData({
      ...data,
      siblingDiscounts: { ...data.siblingDiscounts, title: val }
    });
  };

  const updateDiscountRow = (index: number, field: 'label' | 'tuitionDiscount' | 'enrolmentDiscount', val: string) => {
    const newRows = [...data.siblingDiscounts.rows];
    newRows[index] = { ...newRows[index], [field]: val };
    setData({
      ...data,
      siblingDiscounts: {
        ...data.siblingDiscounts,
        rows: newRows
      }
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 font-mono-custom text-black">
      
      {/* Table Container */}
      <div className={`flex flex-col gap-0 border-4 ${BORDER_COLOR} bg-white`}>
        
        {/* --- SECTION 1: APPLICATION FEE --- */}
        <div className="flex flex-col">
          <div className={`${THEME_COLOR} p-3 text-center border-b-2 ${BORDER_COLOR} font-bold text-lg sm:text-xl uppercase tracking-wide`}>
            <EditableField 
              value={data.applicationFee.title} 
              isEditing={isEditable} 
              onChange={(v) => updateAppFee('title', v)} 
            />
          </div>
          <div className={`p-4 text-center font-bold text-xl sm:text-2xl border-b-4 ${BORDER_COLOR}`}>
            <EditableField 
              value={data.applicationFee.amount} 
              isEditing={isEditable} 
              onChange={(v) => updateAppFee('amount', v)} 
            />
          </div>
        </div>

        {/* --- SECTION 2: ENROLMENT FEE --- */}
        <div className="flex flex-col">
          <div className={`${THEME_COLOR} p-3 text-center border-b-2 ${BORDER_COLOR} font-bold text-lg sm:text-xl uppercase tracking-wide`}>
             <EditableField 
              value={data.enrolmentFee.title} 
              isEditing={isEditable} 
              onChange={(v) => updateEnrolmentFee('title', v)} 
            />
          </div>
          <div className={`p-4 text-center font-bold text-xl sm:text-2xl border-b-4 ${BORDER_COLOR}`}>
             <EditableField 
              value={data.enrolmentFee.amount} 
              isEditing={isEditable} 
              onChange={(v) => updateEnrolmentFee('amount', v)} 
            />
          </div>
        </div>

        {/* --- SECTION 3: SIBLING DISCOUNTS --- */}
        <div className="flex flex-col sm:flex-row">
          {/* Empty spacer on left for desktop layout, or creates the indentation effect */}
          <div className="hidden sm:block sm:w-1/3 border-r-2 border-black bg-white"></div>
          
          <div className="w-full sm:w-2/3">
            {/* Header */}
            <div className={`${THEME_COLOR} p-3 text-center border-b-2 ${BORDER_COLOR} font-bold text-lg uppercase tracking-wide border-t-2 sm:border-t-0 border-black`}>
               <EditableField 
                value={data.siblingDiscounts.title} 
                isEditing={isEditable} 
                onChange={updateSiblingDiscountHeader} 
              />
            </div>

            {/* Sub-headers grid */}
            <div className={`grid grid-cols-2 ${THEME_COLOR} border-b-2 ${BORDER_COLOR}`}>
              <div className={`p-2 text-center border-r-2 ${BORDER_COLOR} font-bold uppercase text-sm sm:text-base`}>
                 <EditableField 
                  value={data.siblingDiscounts.columns.tuition} 
                  isEditing={isEditable} 
                  onChange={(v) => setData({...data, siblingDiscounts: {...data.siblingDiscounts, columns: {...data.siblingDiscounts.columns, tuition: v}}})} 
                />
              </div>
              <div className="p-2 text-center font-bold uppercase text-sm sm:text-base">
                <EditableField 
                  value={data.siblingDiscounts.columns.enrolment} 
                  isEditing={isEditable} 
                  onChange={(v) => setData({...data, siblingDiscounts: {...data.siblingDiscounts, columns: {...data.siblingDiscounts.columns, enrolment: v}}})} 
                />
              </div>
            </div>

            {/* Discount Rows */}
            {data.siblingDiscounts.rows.map((row, index) => (
              <div key={row.id} className="relative flex">
                {/* 
                  The layout trick: The label (e.g., "2nd child") needs to appear to the LEFT of the main table block
                  on desktop, but inside the flow.
                  In the original image, "2nd child" is outside the colored box of Sibling Discounts.
                  To achieve this with the current HTML structure, we need to position the label absolute or negative margin 
                  OR restructure the grid.
                  
                  Let's use a negative margin on the left for the label to pull it into the whitespace we left earlier,
                  or simply render the label in a separate container if we want perfect strictness.
                  
                  Actually, a cleaner way for the DOM is to make the row wrapper extend full width of the parent (including the empty space).
                */}
              </div>
            ))}
          </div>
        </div>

        {/* 
          Refactored Sibling Section Layout to match image perfectly 
          The image shows:
            [ Empty ] | [ SIBLING DISCOUNTS ]
            [ Label ] | [ Tuition ] | [ Enrolment ]
        */}
        
        <div className="grid grid-cols-1 sm:grid-cols-[1.5fr_1.5fr_1.5fr]">
            {/* Header Row: "SIBLING DISCOUNTS" spans right 2 cols */}
             <div className="hidden sm:block bg-white border-t-2 sm:border-t-0 border-black"></div> {/* Spacer */}
             <div className={`col-span-2 ${THEME_COLOR} p-3 text-center border-b-2 ${BORDER_COLOR} border-t-2 sm:border-t-0 border-black font-bold text-lg uppercase tracking-wide border-l-0 sm:border-l-2`}>
                <EditableField 
                  value={data.siblingDiscounts.title} 
                  isEditing={isEditable} 
                  onChange={updateSiblingDiscountHeader} 
                />
             </div>
        </div>

        <div className="grid grid-cols-[1.2fr_1fr_1fr] sm:grid-cols-[1.5fr_1.5fr_1.5fr] border-b-2 border-black last:border-b-0">
             {/* Subheaders */}
             <div className="bg-white border-b-2 border-black sm:border-r-2"></div>
             <div className={`${THEME_COLOR} p-2 text-center border-b-2 border-l-2 ${BORDER_COLOR} font-bold uppercase text-sm sm:text-base`}>
                <EditableField 
                  value={data.siblingDiscounts.columns.tuition} 
                  isEditing={isEditable} 
                  onChange={(v) => setData({...data, siblingDiscounts: {...data.siblingDiscounts, columns: {...data.siblingDiscounts.columns, tuition: v}}})} 
                />
             </div>
             <div className={`${THEME_COLOR} p-2 text-center border-b-2 border-l-2 ${BORDER_COLOR} font-bold uppercase text-sm sm:text-base`}>
                <EditableField 
                  value={data.siblingDiscounts.columns.enrolment} 
                  isEditing={isEditable} 
                  onChange={(v) => setData({...data, siblingDiscounts: {...data.siblingDiscounts, columns: {...data.siblingDiscounts.columns, enrolment: v}}})} 
                />
             </div>

             {/* Dynamic Rows */}
             {data.siblingDiscounts.rows.map((row, index) => (
                <React.Fragment key={row.id}>
                    {/* Label Column (e.g., 2nd Child) */}
                    <div className={`p-3 font-bold text-lg text-center sm:text-right sm:pr-8 flex items-center justify-center sm:justify-end border-b-2 ${BORDER_COLOR} sm:border-r-2`}>
                       <EditableField 
                          value={row.label} 
                          isEditing={isEditable} 
                          onChange={(v) => updateDiscountRow(index, 'label', v)} 
                        />
                    </div>
                    {/* Tuition Value */}
                    <div className={`p-3 text-center font-bold text-lg flex items-center justify-center bg-[#F4F4F4] border-b-2 border-l-2 ${BORDER_COLOR}`}>
                       <EditableField 
                          value={row.tuitionDiscount} 
                          isEditing={isEditable} 
                          onChange={(v) => updateDiscountRow(index, 'tuitionDiscount', v)} 
                        />
                    </div>
                    {/* Enrolment Value */}
                    <div className={`p-3 text-center font-bold text-lg flex items-center justify-center bg-[#F4F4F4] border-b-2 border-l-2 ${BORDER_COLOR}`}>
                       <EditableField 
                          value={row.enrolmentDiscount} 
                          isEditing={isEditable} 
                          onChange={(v) => updateDiscountRow(index, 'enrolmentDiscount', v)} 
                        />
                    </div>
                </React.Fragment>
             ))}
        </div>

      </div>

      {/* Footnote */}
      <div className="mt-6 text-center font-bold text-sm sm:text-base uppercase tracking-wide">
        <EditableField 
          value={data.footnote} 
          isEditing={isEditable} 
          onChange={(v) => setData({...data, footnote: v})} 
          multiline
          className="text-center w-full"
        />
      </div>
    </div>
  );
};