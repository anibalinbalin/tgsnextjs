import React, { useState } from 'react';
import { SchoolFeesTable } from './components/SchoolFeesTable';
import { INITIAL_FEE_DATA } from './constants';
import { FeeData } from './types';

const App: React.FC = () => {
  const [feeData, setFeeData] = useState<FeeData>(INITIAL_FEE_DATA);
  const [isEditable, setIsEditable] = useState(false);
  const [jsonView, setJsonView] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      
      {/* Control Panel (for Webmaster/Dev demonstration) */}
      <div className="max-w-4xl mx-auto mb-8 flex justify-between items-center bg-white p-4 rounded-lg shadow-sm">
        <h1 className="text-xl font-bold text-gray-800">School Fees Component</h1>
        <div className="space-x-4">
           <button 
            onClick={() => setJsonView(!jsonView)}
            className={`px-4 py-2 rounded font-medium transition-colors ${jsonView ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
          >
            {jsonView ? 'Hide Data' : 'View Data JSON'}
          </button>
          <button 
            onClick={() => setIsEditable(!isEditable)}
            className={`px-4 py-2 rounded font-medium transition-colors ${isEditable ? 'bg-green-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
          >
            {isEditable ? 'Done Editing' : 'Edit Contents'}
          </button>
        </div>
      </div>

      {/* The Component Requested */}
      <SchoolFeesTable 
        data={feeData} 
        setData={setFeeData} 
        isEditable={isEditable}
      />

       {/* JSON Preview Panel (to demonstrate how data is structured for the webmaster) */}
       {jsonView && (
        <div className="max-w-4xl mx-auto mt-8 p-6 bg-gray-900 rounded-lg shadow-xl overflow-hidden">
          <h3 className="text-gray-400 text-sm font-mono mb-2 uppercase tracking-wider">Current Data State (JSON)</h3>
          <pre className="font-mono text-xs sm:text-sm text-green-400 overflow-x-auto whitespace-pre-wrap">
            {JSON.stringify(feeData, null, 2)}
          </pre>
          <p className="mt-4 text-gray-500 text-sm italic">
            * This JSON object can be stored in a CMS or database. The component simply renders whatever is passed to it.
          </p>
        </div>
      )}

      <div className="max-w-4xl mx-auto mt-12 text-center text-gray-500 text-sm">
        <p>This table is built with CSS Grid and Tailwind to ensure the "Sibling Discounts" header aligns perfectly with the sub-columns while keeping the label column distinct.</p>
      </div>

    </div>
  );
};

export default App;