import React from 'react';
import CurriculumTable from './components/CurriculumTable';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white p-8 md:p-12 lg:p-24 flex flex-col items-center">
      <div className="max-w-7xl w-full">
        <h1 className="text-3xl font-bold text-[#ba8043] mb-12 text-center md:text-left hidden">
          TGS Curriculum Structure
        </h1>
        
        {/* Table Container */}
        <div className="w-full">
           <CurriculumTable />
        </div>
      </div>
    </div>
  );
};

export default App;