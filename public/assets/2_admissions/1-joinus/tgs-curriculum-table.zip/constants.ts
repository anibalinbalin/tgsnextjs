import { CurriculumPhase } from './types';

// These colors closely match the provided image
export const THEME_COLORS = {
  early: {
    header: 'bg-[#c56a53]', // Terracotta
    cell: 'bg-[#df9682]',   // Light Salmon
  },
  primary: {
    header: 'bg-[#42664f]', // Dark Forest Green
    cell: 'bg-[#87b29b]',   // Sage Green
  },
  secondary: {
    header: 'bg-[#b8823e]', // Bronze/Ochre
    cell: 'bg-[#efc06e]',   // Mustard Yellow
  },
};

export const CURRICULUM_DATA: CurriculumPhase[] = [
  {
    id: 'early-years',
    title: 'Early Years',
    themeColor: THEME_COLORS.early,
    rows: [
      {
        id: 'ey-1',
        age: '2 - 4',
        grade: 'K2 - K3',
        nest: 'Penguins',
        // Starts the "Open" block which spans 5 rows (Early Years + Primary)
        status: {
          text: ['Open'],
          rowSpan: 5,
          textColor: 'text-[#1a4a35]', // Dark green text for status
        },
      },
      {
        id: 'ey-2',
        age: '4 - 6',
        grade: 'K4 - K5',
        nest: 'Jays',
      },
    ],
  },
  {
    id: 'primary-school',
    title: 'Primary School',
    themeColor: THEME_COLORS.primary,
    rows: [
      {
        id: 'ps-1',
        age: '6 - 8',
        grade: 'Grades 1 - 2',
        nest: 'Owls',
      },
      {
        id: 'ps-2',
        age: '8 - 10',
        grade: 'Grades 3 - 4',
        nest: 'Robins',
      },
      {
        id: 'ps-3',
        age: '10 - 12',
        grade: 'Grades 5 - 6',
        nest: 'Falcons',
      },
    ],
  },
  {
    id: 'secondary-school',
    title: 'Secondary School',
    themeColor: THEME_COLORS.secondary,
    rows: [
      {
        id: 'ss-1',
        age: '12 - 14',
        grade: 'Grades 7 - 8',
        nest: 'Bosque',
        // This row has an empty status cell in the image
        status: {
            isEmpty: true,
            rowSpan: 1
        }
      },
      {
        id: 'ss-2',
        age: '14 - 16',
        grade: 'Grades 9 - 10',
        nest: 'Río',
        status: {
          text: ['Grade 9 opening in Feb 2026', 'Grade 10 opening in Feb 2027'],
          rowSpan: 1,
          textColor: 'text-[#b8823e]', // Brownish text
        },
      },
      {
        id: 'ss-3',
        age: '16 - 18',
        grade: 'Grades 11 - 12',
        nest: 'Sierra',
        status: {
          text: ['Grade 11 opening in Feb 2028', 'Grade 12 opening in Feb 2029'],
          rowSpan: 1,
          textColor: 'text-[#b8823e]',
        },
      },
    ],
  },
];

export const TABLE_HEADERS = [
  "Educational Phase",
  "Age Ranges",
  "Grade Equivalent",
  "TGS Nest",
  "Status"
];
