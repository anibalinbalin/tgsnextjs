import React from 'react';
import { CURRICULUM_DATA, TABLE_HEADERS } from '../constants';
import { CurriculumPhase, CurriculumRow } from '../types';

const CurriculumTable: React.FC = () => {
  return (
    <div className="w-full overflow-x-auto pb-4">
      {/* 
        Using border-separate with spacing to create the white grid lines 
        effect seen in the original image.
      */}
      <table className="min-w-[900px] w-full border-separate border-spacing-1">
        <thead>
          <tr>
            {TABLE_HEADERS.map((header, index) => (
              <th
                key={index}
                className={`
                  pb-6 pt-2 px-4 text-center font-bold text-[#ba8043] text-lg tracking-wide
                  ${index === 0 ? 'w-1/5' : ''}
                  ${index === 4 ? 'w-1/6' : ''}
                `}
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {CURRICULUM_DATA.map((phase: CurriculumPhase) => {
            return (
              <React.Fragment key={phase.id}>
                {phase.rows.map((row: CurriculumRow, rowIndex: number) => {
                  const isFirstRowOfPhase = rowIndex === 0;
                  
                  return (
                    <tr key={row.id} className="h-16">
                      {/* Educational Phase Column (RowSpan) */}
                      {isFirstRowOfPhase && (
                        <td
                          rowSpan={phase.rows.length}
                          className={`${phase.themeColor.header} text-white font-bold text-lg text-center align-middle rounded-sm px-6`}
                        >
                          {phase.title}
                        </td>
                      )}

                      {/* Data Columns */}
                      <td className={`${phase.themeColor.cell} text-white font-medium text-center align-middle rounded-sm py-6`}>
                        {row.age}
                      </td>
                      <td className={`${phase.themeColor.cell} text-white font-medium text-center align-middle rounded-sm py-6`}>
                        {row.grade}
                      </td>
                      <td className={`${phase.themeColor.cell} text-white font-medium text-center align-middle rounded-sm py-6`}>
                        {row.nest}
                      </td>

                      {/* Status Column (Custom Logic) */}
                      {row.status && (
                        <td
                          rowSpan={row.status.rowSpan || 1}
                          className="bg-white text-center align-middle rounded-sm px-4"
                        >
                          {/* If it's not empty, render text */}
                          {!row.status.isEmpty && row.status.text && (
                            <div className={`flex flex-col justify-center gap-1 ${row.status.textColor || 'text-gray-800'} font-medium text-lg`}>
                              {row.status.text.map((line, i) => (
                                <span key={i} className={line === 'Open' ? 'text-2xl' : 'text-sm font-bold'}>
                                  {line}
                                </span>
                              ))}
                            </div>
                          )}
                          
                          {/* Render horizontal separator lines for Secondary school split rows if needed visually, 
                              though border-spacing handles most of the grid look. 
                              The specific status styling is minimal as per image.
                          */}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default CurriculumTable;
