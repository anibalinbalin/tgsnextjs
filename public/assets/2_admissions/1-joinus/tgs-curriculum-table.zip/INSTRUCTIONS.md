# Webmaster Guide: Updating the TGS Curriculum Table

This component is designed to be easily editable without modifying the core React code. All text, numbers, and status messages are stored in a separate configuration file.

## 1. Where to make changes
Open the file: **`constants.ts`**

## 2. Changing Age, Grade, or Nest Names
Scroll to the `CURRICULUM_DATA` constant. It is organized by school phase (Early Years, Primary, Secondary).

Find the row you want to edit and change the text inside the quotes.

**Example:**
```typescript
{
  id: 'ey-1',
  age: '2 - 4',         // <--- Edit this
  grade: 'K2 - K3',     // <--- Edit this
  nest: 'Penguins',     // <--- Edit this
  // ...
}
```

## 3. Updating "Status" (Rightmost Column)
The status column uses a special configuration because some cells span across multiple rows (like the big "Open" status).

Look for the `status` property in a row:

### To update text (e.g., opening dates):
Edit the text inside the `text` array.
```typescript
status: {
  text: ['Grade 9 opening in Feb 2026', 'Grade 10 opening in Feb 2027'], 
  // ...
}
```

### To change how many rows a status covers:
Change the `rowSpan` number.
- If `rowSpan` is 5, it covers the current row plus the next 4.
- If you split a status, you might need to add a `status` object to a row that previously didn't have one (rows without a `status` property defined are assumed to be covered by the previous row's `rowSpan`).

### To remove a status box (make it empty/white):
Set `isEmpty: true`.
```typescript
status: {
    isEmpty: true,
    rowSpan: 1
}
```

## 4. Changing Colors
The colors are defined at the top of `constants.ts` in `THEME_COLORS`.
You can replace the Tailwind color codes (e.g., `bg-[#c56a53]`) with new hex codes.

```typescript
export const THEME_COLORS = {
  early: {
    header: 'bg-[#c56a53]', 
    cell: 'bg-[#df9682]',
  },
  // ...
};
```
