export interface StatusConfig {
  text?: string[];
  rowSpan?: number;
  textColor?: string;
  isEmpty?: boolean;
}

export interface CurriculumRow {
  id: string;
  age: string;
  grade: string;
  nest: string;
  // If defined, this row will render a status cell. 
  // If undefined, it assumes the previous row's status cell spans over this one.
  status?: StatusConfig;
}

export interface CurriculumPhase {
  id: string;
  title: string;
  themeColor: {
    header: string;
    cell: string;
  };
  rows: CurriculumRow[];
}
