# Webmaster Guide: Updating the Space Availability Table

This component is configured via `constants.ts`. The table is built dynamically based on the data structure in that file.

## 1. Changing the Main Title
Open `constants.ts` and find the `TABLE_TITLE` variable at the top.
```typescript
export const TABLE_TITLE = "Space Availability for the 2026 Academic Year...";
```

## 2. Structure Overview
The data is nested in three levels:
1. **Phases** (Early Years, Primary, Secondary)
2. **Nests** (Penguins, Jays, Owls, etc.)
3. **Grades** (K2, K3, Grade 1, etc.)

## 3. Editing Data
Scroll to `CURRICULUM_DATA`.

### Changing a Grade's Status
Find the specific nest and grade you want to update.
Change the `status` string.

**Example:**
```typescript
{
  id: 'robins',
  name: 'Robins',
  grades: [
    { 
      id: 'g3', 
      name: 'Grade 3', 
      status: '1 Space(s) Available' // <--- Change this text
    },
    // ...
  ],
},
```

### Adding a New Grade
If a nest expands (e.g., adding Grade 13), add a new object to the `grades` array inside that nest.
```typescript
{ id: 'g13', name: 'Grade 13', status: 'Opening Soon' }
```

### Changing Colors
Colors are defined in `THEME_COLORS` at the top of the file.
- `header`: The main title bar color.
- `dark`: The leftmost column color (Phase).
- `light`: The background color for Nests, Grades, and Status cells.

## 4. Tips
- The table automatically calculates how tall the "Phase" and "Nest" cells should be based on the number of grades inside them. You don't need to manually set `rowSpan`.
- Keep IDs unique where possible, though they are primarily used for React rendering keys.
