export interface GradeData {
  id: string;
  name: string;   // e.g. "K2"
  status: string; // e.g. "Waiting List Only"
}

export interface NestData {
  id: string;
  name: string;   // e.g. "Penguins"
  grades: GradeData[];
}

export interface PhaseData {
  id: string;
  name: string;   // e.g. "EARLY YEARS"
  themeColor: {
    dark: string;  // Leftmost column background
    light: string; // Nest, Grade, and Status background
  };
  nests: NestData[];
}
