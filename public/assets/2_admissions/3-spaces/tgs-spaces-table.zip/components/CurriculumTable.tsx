import React from 'react';
import { CURRICULUM_DATA, TABLE_TITLE, THEME_COLORS } from '../constants';
import { PhaseData, NestData, GradeData } from '../types';

const CurriculumTable: React.FC = () => {
  return (
    <div className="w-full overflow-x-auto pb-4">
      {/* 
        border-separate + border-spacing-1 creates the white grid lines between cells.
      */}
      <table className="min-w-[800px] w-full border-separate border-spacing-0.5">
        <thead>
          <tr>
            <th
              colSpan={4}
              className={`${THEME_COLORS.header} text-white py-4 px-6 text-xl md:text-2xl font-bold text-center tracking-wide rounded-t-sm`}
            >
              {TABLE_TITLE}
            </th>
          </tr>
        </thead>
        <tbody className="text-white font-medium text-lg">
          {CURRICULUM_DATA.map((phase: PhaseData) => {
            // Calculate total rows for this phase to set rowSpan
            const totalPhaseRows = phase.nests.reduce(
              (acc, nest) => acc + nest.grades.length,
              0
            );

            return (
              <React.Fragment key={phase.id}>
                {phase.nests.map((nest: NestData, nestIndex: number) => {
                  return nest.grades.map((grade: GradeData, gradeIndex: number) => {
                    // Is this the very first row of the entire Phase?
                    const isPhaseFirstRow = nestIndex === 0 && gradeIndex === 0;
                    // Is this the first row of this specific Nest?
                    const isNestFirstRow = gradeIndex === 0;

                    return (
                      <tr key={grade.id} className="h-14">
                        {/* PHASE COLUMN */}
                        {isPhaseFirstRow && (
                          <td
                            rowSpan={totalPhaseRows}
                            className={`${phase.themeColor.dark} text-center align-middle font-bold text-xl uppercase tracking-wider px-4 border border-white`}
                            style={{ width: '20%' }}
                          >
                            {phase.name}
                          </td>
                        )}

                        {/* NEST COLUMN */}
                        {isNestFirstRow && (
                          <td
                            rowSpan={nest.grades.length}
                            className={`${phase.themeColor.light} text-center align-middle px-4 border border-white`}
                            style={{ width: '20%' }}
                          >
                            {nest.name}
                          </td>
                        )}

                        {/* GRADE COLUMN */}
                        <td className={`${phase.themeColor.light} text-center align-middle px-4 border border-white`}>
                          {grade.name}
                        </td>

                        {/* STATUS COLUMN */}
                        <td className={`${phase.themeColor.light} text-center align-middle px-4 border border-white`}>
                          {grade.status}
                        </td>
                      </tr>
                    );
                  });
                })}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default CurriculumTable;
